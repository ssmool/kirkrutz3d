import bpy
import os
import subprocess
import glob


class KR3D_RunPipeline(bpy.types.Operator):
    bl_idname = "kr3d.run_full_pipeline"
    bl_label = "Run Analyzer + 3D Builder"

    def execute(self, context):
        s = context.scene.kr3d_settings

        img = s.image_path
        analyze = s.analyze_script
        bitmap = s.bitmap_script
        out = s.output_dir

        if not (os.path.isfile(img) and os.path.isfile(analyze) and os.path.isfile(bitmap)):
            self.report({"ERROR"}, "Missing required files.")
            return {"CANCELLED"}

        # 1) Run analyzemap.py
        cmd1 = [
            "python", analyze, img,
            "--top", str(s.top_colors),
            "--threads", "6",
            "--emit-blender",
            "--csv"
        ]

        subprocess.run(cmd1, cwd=os.path.dirname(img))

        json_file = os.path.join(os.path.dirname(img), "map.colors.json")
        if not os.path.exists(json_file):
            self.report({"ERROR"}, "map.colors.json not generated.")
            return {"CANCELLED"}

        # 2) Run blender in background + bitmap_3d.py
        cmd2 = [
            "blender", "--background", "--python", bitmap, "--",
            json_file,
            "--image-dir", os.path.dirname(img),
            "--out-dir", out,
            "--sample", "4",
            "--height-scale", str(s.height_scale),
            "--rgb-tolerance", str(s.rgb_tolerance),
            "--solidify", str(s.solidify),
            "--export-format", "obj",
            "--export-combined", "glb",
            "--render-preview",
            "--preview-size", "1024"
        ]

        subprocess.run(cmd2)

        self.report({"INFO"}, "Pipeline complete.")
        return {"FINISHED"}


class KR3D_ImportGenerated(bpy.types.Operator):
    bl_idname = "kr3d.import_generated"
    bl_label = "Import Generated Models"

    def execute(self, context):
        s = context.scene.kr3d_settings
        out = s.output_dir

        objs = glob.glob(os.path.join(out, "*.obj"))
        glbs = glob.glob(os.path.join(out, "*.glb"))

        for f in objs:
            bpy.ops.import_scene.obj(filepath=f)

        for f in glbs:
            bpy.ops.import_scene.gltf(filepath=f)

        self.report({"INFO"}, "Imported generated 3D files.")
        return {"FINISHED"}


class KR3D_ShowPreview(bpy.types.Operator):
    bl_idname = "kr3d.open_preview"
    bl_label = "Open Preview Window"

    def execute(self, context):
        s = context.scene.kr3d_settings
        out = s.output_dir

        preview_files = glob.glob(os.path.join(out, "preview_*.png"))
        if not preview_files:
            self.report({"ERROR"}, "No preview images.")
            return {"CANCELLED"}

        # Open preview in OS viewer
        for f in preview_files:
            subprocess.Popen(["xdg-open" if os.name == "posix" else "start", f], shell=True)

        return {"FINISHED"}

