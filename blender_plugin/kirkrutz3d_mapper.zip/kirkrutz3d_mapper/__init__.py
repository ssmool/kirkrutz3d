bl_info = {
    "name": "KirkRutz3D Mapper",
    "author": "#asytrick - github.com/ssmool/kirkrutz3d",
    "version": (1, 0, 0),
    "blender": (2, 93, 0),
    "location": "View3D > N-Panel > KirkRutz3D",
    "description": "Runs analyzemap.py + bitmap_3d.py and imports generated 3D objects",
    "category": "Import-Export",
}

import bpy
from . import operators


class KR3D_PT_MainPanel(bpy.types.Panel):
    bl_label = "KirkRutz3D Mapper"
    bl_idname = "KR3D_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "KirkRutz3D"

    def draw(self, context):
        layout = self.layout
        prefs = context.scene.kr3d_settings

        col = layout.column(align=True)
        col.prop(prefs, "image_path")
        col.prop(prefs, "analyze_script")
        col.prop(prefs, "bitmap_script")
        col.prop(prefs, "output_dir")

        layout.separator()
        col = layout.column(align=True)
        col.prop(prefs, "top_colors")
        col.prop(prefs, "rgb_tolerance")
        col.prop(prefs, "height_scale")
        col.prop(prefs, "solidify")

        layout.separator()
        layout.operator("kr3d.run_full_pipeline", icon="FILE_TICK")
        layout.operator("kr3d.import_generated", icon="IMPORT")
        layout.operator("kr3d.open_preview", icon="RENDER_STILL")


class KR3D_Settings(bpy.types.PropertyGroup):
    image_path: bpy.props.StringProperty(
        name="Map Image",
        subtype="FILE_PATH"
    )
    analyze_script: bpy.props.StringProperty(
        name="analyzemap.py",
        subtype="FILE_PATH"
    )
    bitmap_script: bpy.props.StringProperty(
        name="bitmap_3d.py",
        subtype="FILE_PATH"
    )
    output_dir: bpy.props.StringProperty(
        name="Output Folder",
        subtype="DIR_PATH"
    )

    top_colors: bpy.props.IntProperty(name="Top Colors", default=50)
    rgb_tolerance: bpy.props.IntProperty(name="RGB Tolerance", default=12)
    height_scale: bpy.props.FloatProperty(name="Height Scale", default=0.02)
    solidify: bpy.props.FloatProperty(name="Solidify", default=0.6)


classes = (
    KR3D_Settings,
    KR3D_PT_MainPanel,
    operators.KR3D_RunPipeline,
    operators.KR3D_ImportGenerated,
    operators.KR3D_ShowPreview
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.kr3d_settings = bpy.props.PointerProperty(type=KR3D_Settings)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    del bpy.types.Scene.kr3d_settings

